#include<iostream>
using namespace std;

int main(){
    long long int t;
    cin>>t;
    bool answer[t];
    for(long long int k=0;k<t;k++){
    long long int n;
    cin>>n;
    long long int a[n];
    for(long long int i=0;i<n;i++){
        cin>>a[i];

    }

if(n%2!=0){ answer[k]=true;}

else{

   long long int diff;
   
        for(long long int i=0;i<n-2;i++){
           diff=a[i+1]-a[i];
                a[i+1]=a[i+1]-diff;
                a[i+2]=a[i+2]-diff;
            
            }
            
        
        if(a[n-1]>=a[n-2]){
            answer[k]=true;
        } 
            else answer[k]=false;
        
    }
    }
    

        for (long long int i = 0; i < t; i++)
        {
            if(answer[i]==true){
                cout<<"YES"<<endl;
            }
            else cout<<"NO"<<endl;
        }
            
     return 0;
}
//QUESTION_1       week 2