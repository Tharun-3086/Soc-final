#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int mod(int a, int b) {
    if(a>b) return a-b;
    else if(b>a) return b-a;
    else if(a==b) return 0;
}

int distance(int x1, int x2, int y1, int y2) {
    return mod(x1, x2) + mod(y1, y2);
}

int main() {
    int t;
    cin >> t;

    vector<int> d_store(t);
    vector<vector<pair<int, int>>> all_pairs(t); // Store pairs of points for each test case

    for (int z = 0; z < t; z++) {
        int n;
        cin >> n;

        vector<int> a(2 * n);
        for (int i = 0; i < 2 * n; i++) {
            cin >> a[i];
        }

        vector<int> sort_a = a; // Copy a into sort_a
        sort(sort_a.begin(), sort_a.end());

        int shortest_d = 0;
        vector<pair<int, int>> pairs; // To store pairs for this test case

        for (int i = 0; i < n; i++) {
            int x1 = sort_a[i];
            int x2 = sort_a[2 * n - 1 - i];
            pairs.push_back(make_pair(x1, x2)); // Storing pairs
        }

        for (int i = 0; i < n - 1; i++) {
            shortest_d += distance(pairs[i].first, pairs[i + 1].first, pairs[i].second, pairs[i + 1].second);
        }

        d_store[z] = shortest_d;//saving distances
        all_pairs[z] = pairs; // Saving pairs
    }

    // Output results
    for (int i = 0; i < t; i++) {
        cout << d_store[i] << endl;
        for (const auto& p : all_pairs[i]) {
            cout << p.first << " " << p.second << endl;
        }
    }

    return 0;
}
