#include<iostream>
using namespace std;

int main(){
        int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){
    int n;
    cin>>n;

    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }

    int min=arr[0];
    for(int j=1;j<n;j++){
        if(min>=arr[j]){
            min=arr[j];
        }
    }
    cout<<min<<endl;
    }
}

    return 0;
}