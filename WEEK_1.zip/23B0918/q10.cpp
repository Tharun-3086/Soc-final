#include <iostream>
using namespace std;

int main() {
    int t;
    cin>>t;

    if(t>=1&&t<=100){
for(int i=0;i<t;i++){

    int n, k; // length of the array and target subarray size respectively
    cin>>n>>k;

    int arr[n];
    for (int i=0; i<n; i++) {
        cin >> arr[i];
    }

    for (int i=0; i<= n - k; i++) {
        int highest = arr[i];
        for (int j=i; j<i+k; j++) {
            if (arr[j]> highest) {
                highest = arr[j];
            }
        }
        cout <<  highest<<" ";
    }

  
}
    }
      return 0;
}