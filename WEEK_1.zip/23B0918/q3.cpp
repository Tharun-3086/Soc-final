#include<iostream>
using namespace std;


int main(){
    int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){

    int n,k;
    cin>>n>>k;
    int numbers[n+1];
    for (int i=1;i<n;i++){
        cin>>numbers[i];
    }


for (int i=1;i<n;i++){
    for (int j=1;j<n;j++)
    {
        if(numbers[i]+numbers[j]==k&&i<j){

            cout<<i<<" "<<j<<endl;
            break;
            
        }
    
    }
    
    
}
}
}
else cout<<"-1"<<endl;
    
    return 0;
}