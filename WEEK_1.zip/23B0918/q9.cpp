#include <iostream>
#include <string>
using namespace std;

bool compare(char* A, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (A[j] == A[i]) {
                return false;
            }
        }
    }
    return true;
}

int main() {
        int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){
    int k;
    cin >> k;
    cin.ignore(); 

    string str;
    getline(cin, str);

    int l = str.length();

    char compare_array[k];
    int increment = 0;

    for (int i = 0; i <= l - k; i++) {
        for (int j = i; j < i + k; j++) {
            compare_array[j - i] = str[j];
        }
        bool check = compare(compare_array, k);
        if (check) {
            increment++;
        }
    }

    cout << increment << endl;
}
}

    return 0;
}

