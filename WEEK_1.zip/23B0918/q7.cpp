#include <iostream>
#include <string>
using namespace std;

string Binary(int n) {
    if (n == 0) return "0";

    string binary = "";
    while (n > 0) {
        if (n % 2 == 0) {
            binary = "0" + binary; 
                                    // adding bits at the front of the string.
        } else {
            binary = "1" + binary;
        }
        n /= 2;
    }
    return binary;
}


int main() {
      int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){
    int n;
    cin >> n;
    string binary = Binary(n);
    int fail_count = 0;

    for (int i = 0; i<n+1; i++) {
        string binary_i = Binary(i);

        int min_length = min(binary.length(), binary_i.length());

        for (int j=0; j<min_length; j++) {
            if (binary[binary.length()-1-j] == '1' && binary_i[binary_i.length()-1-j] == '1') {
                fail_count++;
                break; // exit the inner loop when a failure is found
            }
        }
    }

    cout << n - fail_count << endl;
}
}
    
    return 0;
}
