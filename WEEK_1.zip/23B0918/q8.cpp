#include <iostream>
using namespace std;

int ans(int* A, int n, int k){
    int count=0;
    for (int i=0; i<n;i++) {
        int temp = 0;
        for (int j=i;j<n;j++) {
            temp^= A[j];
            if (temp==k) {
                count++;
        }
    }
    }

    return count;
}

int main(){
      int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){
    int n, k;
    cin>>n>>k;

    int arr[n];
    for (int i=0; i<n; i++) {
        cin>>arr[i];
    }

    cout<< ans(arr, n, k);
    }
}


    return 0;
}