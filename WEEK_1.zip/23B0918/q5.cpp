#include<iostream>
using namespace std;


int main(){
    int t;//no of testcases
    cin>>t;
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){

    int n,k;
    cin>>n>>k;
    int numbers[n];
    for (int i=0;i<n;i++){
        cin>>numbers[i];
    }

bool checked;

for (int i=0;i<n;i++){
    for (int j=i+1;j<n;j++)
    {
        if(numbers[i]+numbers[j]==k){

            cout<<i<<" "<<j<<endl;
            checked=true;
            break;
            
        }
    
    }
    
    
}

if(!checked){
     cout<<-1<<" "<<-1<<endl;
}
}
}

    
    return 0;
}