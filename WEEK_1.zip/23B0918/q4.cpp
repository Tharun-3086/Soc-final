#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;
    if (t >= 1 && t <= 100) { 
        for (int i=0; i<t; i++) {
            int n;
            cin >>n; 
            int nums[n];

            for (int j = 0; j < n; j++) { // Input array elements
                cin >> nums[j];
            }

              int ans=-1;
               for(int i=0;i<31;i++){//calculating lowest int=-2^31 and alloting it to max_sum.
                    ans*=2;
             }

            int max_sum = ans; 

            for (int j = 0; j<n; j++) { 
                int sum = 0; // Sum of subarray elements
                for (int k = j; k<n; k++) { 
                    sum +=nums[k];
                    if (sum >max_sum) {
                        max_sum = sum;
                    }
                }
            }

            cout <<max_sum<< endl;
        }
    }

    return 0;
}
