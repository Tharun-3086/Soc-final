#include<iostream>
using namespace std;


int main(){
        int t;
        cin>>t;
        if(t>=1&&t<=100){
for(int i=0;i<t;i++){

        
                int n,k;
                cin>>n>>k;//no of elements and target
                int nums[n];
               
               
               for (int i=0;i<n;i++){//input elements
                     cin>>nums[i];
                  }

                int storer[1000];// stores min subarray size possible for sums of each respecetive element


                for ( int i=0;i<n;i++){
                        bool checked;
                        int sum=0,size=0;//sum=sub array elements sum
                        int j=i;
                        while(j<n){
                                sum+=nums[j];
                                j++; size++;//upon adding next element one by one, "size" will be increment operator.


                                if (sum>= k){
                                        checked=true;
                                        break;
                                }
                        }
                    if (checked){
                                storer[i]=size;
                        }
                        
                        else if (!checked)
                        {
                                storer[i]=n+1;
                        }

                }
                
                if (storer[0]!=n+1){
                int min_size = storer[0];

                for (int i = 1; i < n; i++) {
                        if (storer[i] < min_size) {
                        min_size = storer[i];
                        }
                }

                cout << min_size << endl;}
                else{
                        cout<<"-1"<<endl;
                }
        }
        }

        return 0;
        }
        
        
