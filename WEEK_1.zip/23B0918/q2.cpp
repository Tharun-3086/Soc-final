#include<iostream>
#include<string>
using namespace std;


  int find(string s) {
    int a=0,A=0,b=0,B=0,c=0,C=0;

    for (char c : s) {
        if (c == '(') {
            a++;
        }
        if (c == ')') {
            A++;
        }
        if (c == '{') {
            b++;
        }
        if (c == '}') {
            B++;
        }
        if (c == '[') {
            c++;
        }
        if (c == ']') {
            C++;
        }
    }
    
return (a==A&&b==B&&c==C);

         
    
  }

int main(){
    int t;//no of testcases
    cin>>t;
    cin.ignore();
    
if(t>=1&&t<=100){
for(int i=0;i<t;i++){

    string str;
    getline(cin,str);
    
  if(find(str)==1){
      cout<<"true"<<endl;
      }
      else {cout<<"false"<<endl;}
}
}
     
    return 0;
}